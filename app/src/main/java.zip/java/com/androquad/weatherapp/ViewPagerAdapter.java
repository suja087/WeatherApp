package com.androquad.weatherapp;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.widget.Toast;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URL;

/**
 * Created by sujon on 03/04/2016.
 */
public class ViewPagerAdapter extends FragmentPagerAdapter {
String url;
    public ViewPagerAdapter(String finalurl, FragmentManager fm) {
        super(fm);
        this.url = finalurl;
        AppController ac = AppController.getInstance();
        ac.addToRequestQueue(request);
    }
    final JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, new Response.Listener<JSONObject>() {
        @Override
        public void onResponse(JSONObject response) {
            LongOperation.onResponse(response);

            try {
                JSONObject object = response.getJSONObject("query");
                JSONObject results=object.getJSONObject("results");
                JSONObject channel=results.getJSONObject("channel");
                JSONObject item=channel.getJSONObject("item");
                JSONArray forecast = item.getJSONArray("forecast");
            } catch (JSONException e) {
                e.printStackTrace();
            }


        }
    }, new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            if (error instanceof NoConnectionError){
              //  Toast.makeText(getAp, "No Internet Connection", Toast.LENGTH_SHORT).show();
            }
        }
    });


    @Override
    public Fragment getItem(int position) {
        /** Show a Fragment based on the position of the current screen */
        if (position == 0) {
            return new Fragment1();
        } else
            return new Fragment2();
    }

    @Override
    public int getCount() {
        // Show 2 total pages.
        return 2;
    }
}

